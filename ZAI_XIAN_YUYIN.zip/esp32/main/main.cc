/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_spi_flash.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_partition.h"
#include "driver/i2s.h"
#include "driver/adc.h"
#include "audio.h"
#include "esp_adc_cal.h"
#include "esp_rom_sys.h"

#include <string.h>
#include <sys/param.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"
#include "addr_from_stdin.h"
#include "lwip/err.h"
#include "lwip/sockets.h"

#include "main_functions.h"
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_spi_flash.h"
#include "esp_heap_caps.h"
#include "driver/gpio.h"

extern void init_audio();
extern void init_feature_provide();
extern void i2s_sample();
extern void i2s_play_flash();
extern void get_fearure_buffer();
extern void wifi_tcp_init();
extern void example_flash_init();
extern void i2s_record();
extern void i2s_tcp_conn_audio();
extern void i2s_wake_up_audio();

#define GPIO_OUTPUT_IO_2    (gpio_num_t)2
#define GPIO_OUTPUT_PIN_SEL  (1ULL<<GPIO_OUTPUT_IO_2) 
int g_led_switch=0;
uint8_t g_wake_up=0;
extern uint8_t g_tcp_data_receiving;
extern uint8_t g_tcp_status;

int tf_main(int argc, char* argv[]) {

  while (true) {
   
    loop();    
    vTaskDelay(2 / portTICK_PERIOD_MS);
  }
}
int feature_task(int argc, char* argv[]) {

  while (true) {
    get_fearure_buffer();
    vTaskDelay(2 / portTICK_PERIOD_MS);
  }
}
extern "C" void app_main() {
  int ttime=0;

  ESP_ERROR_CHECK(nvs_flash_init());
  ESP_ERROR_CHECK(esp_netif_init());
  ESP_ERROR_CHECK(esp_event_loop_create_default());
  example_flash_init();
  wifi_tcp_init();
  init_audio();
  while(g_tcp_status==0)
  {
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
  i2s_tcp_conn_audio();

  gpio_config_t io_conf;
  //disable interrupt
  io_conf.intr_type = GPIO_INTR_DISABLE;
  //set as output mode
  io_conf.mode = GPIO_MODE_OUTPUT;
  //bit mask of the pins that you want to set,e.g.GPIO18/19
  io_conf.pin_bit_mask = GPIO_OUTPUT_PIN_SEL;
  //disable pull-down mode
  io_conf.pull_down_en = (gpio_pulldown_t)0;
  //disable pull-up mode
  io_conf.pull_up_en = (gpio_pullup_t)0;
  //configure GPIO with the given settings
  gpio_config(&io_conf);


  setup();  
  
  init_feature_provide();  

  xTaskCreate((TaskFunction_t)&tf_main, "tensorflow", 5 * 1024, NULL, 1, NULL);
  xTaskCreate((TaskFunction_t)&feature_task, "feature_task", 5 * 1024, NULL, 2, NULL);
  
  while(1)
  {
    i2s_sample();

    if(g_wake_up>0)
    {
      ttime+=3;
      //亮灯
      gpio_set_level(GPIO_OUTPUT_IO_2, 1);
      if(g_wake_up==1)//唤醒答复词
      {
        i2s_wake_up_audio();
        g_wake_up=2;
      }
      else if(g_wake_up==2)//录音同时上传
      {
        i2s_record();
        if(ttime>1600)//默认最长5S
        {
          g_wake_up=3;
        }
      }
      else if(g_wake_up==3)//接收语音
      {
        //等待接收完毕
        if(g_tcp_data_receiving==1)
        {
          g_tcp_data_receiving=0;
          vTaskDelay(500 / portTICK_PERIOD_MS);
          //0.5s无新数据判断接收完毕
          if(g_tcp_data_receiving==0)
          {
            i2s_play_flash();//开始播放
            g_wake_up=0;
          }
        }
        else
        {
          if(ttime>5000)//接收超时
          {
            g_wake_up=0;
            printf("recv time out\n\r");

          }
        }
        
      }
      
    }
    else
    {
      ttime=0;
      gpio_set_level(GPIO_OUTPUT_IO_2, 0);
    }
    
    // if(ttime++==5000)
    // {
    //   printf("heap:%d\n\r",heap_caps_get_free_size(MALLOC_CAP_8BIT));
    // }  
    vTaskDelay(3 / portTICK_PERIOD_MS); 
  }
}