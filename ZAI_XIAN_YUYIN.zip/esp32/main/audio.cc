#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_spi_flash.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_partition.h"
#include "driver/i2s.h"
#include "driver/adc.h"
#include "audio.h"
#include "esp_adc_cal.h"
#include "esp_rom_sys.h"

#include <string.h>
#include <sys/param.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"
#include "addr_from_stdin.h"
#include "lwip/err.h"
#include "lwip/sockets.h"


static const char* TAG = "ad/da";
#define V_REF   1100
#define ADC1_TEST_CHANNEL (ADC1_CHANNEL_7) // GPIO 35

#define PARTITION_NAME   "storage"

/*---------------------------------------------------------------
                            EXAMPLE CONFIG
---------------------------------------------------------------*/
//enable record sound and save in flash
#define RECORD_IN_FLASH_EN        (1)
//enable replay recorded sound in flash
#define REPLAY_FROM_FLASH_EN      (1)

//i2s number
#define EXAMPLE_I2S_NUM           (I2S_NUM_0)
//i2s sample rate
#define EXAMPLE_I2S_SAMPLE_RATE   (16000)
//i2s data bits
#define EXAMPLE_I2S_SAMPLE_BITS   (I2S_BITS_PER_SAMPLE_16BIT)
//enable display buffer for debug
#define EXAMPLE_I2S_BUF_DEBUG     (0)
//I2S read buffer length
#define EXAMPLE_I2S_READ_LEN      (16 * 1024)
//I2S data format
#define EXAMPLE_I2S_FORMAT        (I2S_CHANNEL_FMT_ONLY_LEFT)
//I2S channel number
#define EXAMPLE_I2S_CHANNEL_NUM   ((EXAMPLE_I2S_FORMAT < I2S_CHANNEL_FMT_ONLY_RIGHT) ? (2) : (1))
//I2S built-in ADC unit
#define I2S_ADC_UNIT              ADC_UNIT_1
//I2S built-in ADC channel
#define I2S_ADC_CHANNEL           ADC1_CHANNEL_7 //P35

//flash record size, for recording 5 seconds' data
#define FLASH_RECORD_SIZE         (1024*4*120)
#define FLASH_ERASE_SIZE          (FLASH_RECORD_SIZE)
//sector size of flash
#define FLASH_SECTOR_SIZE         (0x1000)
//flash read / write address
#define FLASH_ADDR                (0x200000)

#define ONE_BLOCK 160
uint16_t sample_data[ONE_BLOCK] = {0};

uint16_t g_sample_buff[3*1024];
int g_sample_buff_writer;
extern uint8_t g_tcp_send_buff[4*1024];
extern void tcp_send_data(uint8_t* payload,int len);
extern uint8_t g_wake_up;

const esp_partition_t *data_partition = NULL;
int g_flash_wr_counter = 0;
int g_flash_rd_counter = 0;
i2s_port_t i2s_num = EXAMPLE_I2S_NUM;

uint8_t* flash_read_buff = (uint8_t*) calloc(FLASH_SECTOR_SIZE, sizeof(char));
uint8_t* i2s_write_buff = (uint8_t*) calloc(EXAMPLE_I2S_READ_LEN, sizeof(char));

/**
 * @brief I2S ADC/DAC mode init.
 * 
 */
void init_audio(void)
{
     
     i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN | I2S_MODE_ADC_BUILT_IN),
        .sample_rate =  EXAMPLE_I2S_SAMPLE_RATE,
        .bits_per_sample = EXAMPLE_I2S_SAMPLE_BITS,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_MSB,
        .intr_alloc_flags = 0,
        .dma_buf_count = 2,
        .dma_buf_len = 1024,
        .use_apll = 1,
     };
     //install and start i2s driver
     i2s_driver_install(i2s_num, &i2s_config, 0, NULL);
     //init DAC pad
     // i2s_set_dac_mode(I2S_DAC_CHANNEL_BOTH_EN);
     //init ADC pad
     i2s_set_adc_mode(I2S_ADC_UNIT, I2S_ADC_CHANNEL);
     i2s_adc_enable(i2s_num);
     //i2s_adc_disable(i2s_num);
     i2s_set_clk(EXAMPLE_I2S_NUM, 16000, EXAMPLE_I2S_SAMPLE_BITS, I2S_CHANNEL_MONO);
}

void i2s_sample()
{
    size_t ret_num=0;
    i2s_read(i2s_num, sample_data, ONE_BLOCK*2, &ret_num, 10000);
    for (int i = 0; i < ONE_BLOCK; i++) {
        if(g_sample_buff_writer<3*1024)
        {
            g_sample_buff[g_sample_buff_writer++]=(sample_data[i]&0xFFF)<<4; 
        }
        
    }     
    // printf("%d\n",(sample_data[20]&0xFFF)<<4);  
}
void i2s_record()
{
    if(g_sample_buff_writer>1600)
    {
        int16_t temp=0;
        g_sample_buff_writer-=1600;
        for(int i=0,j=0;i<1600;i++)
        {
            temp=g_sample_buff[i]-21876;
            g_tcp_send_buff[j++]= temp&0xFF;
            g_tcp_send_buff[j++]= temp>>8;
            if(i<g_sample_buff_writer)
            {
                g_sample_buff[i]=g_sample_buff[1600+i];
            }
        }
        tcp_send_data(g_tcp_send_buff,3200);

        printf("recording\n");
    }
}
int example_i2s_dac_data_scale(uint8_t* d_buff, uint8_t* s_buff, uint32_t len)
{
    uint32_t j = 0;
    for (int i = 0; i < len; i++) {
        d_buff[j++] = 0;
        d_buff[j++] = s_buff[i];
    }
    return (len * 2);

}
void example_flash_init()
{

    printf("Erasing flash \n");
    
    data_partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA,
            ESP_PARTITION_SUBTYPE_DATA_FAT, PARTITION_NAME);
    if (data_partition != NULL) {
        printf("partiton addr: 0x%08x; size: %d; label: %s\n", data_partition->address, data_partition->size, data_partition->label);
    }
    printf("Erase size: %d Bytes\n", FLASH_ERASE_SIZE);
    ESP_ERROR_CHECK(esp_partition_erase_range(data_partition, 0, FLASH_ERASE_SIZE));
    g_flash_wr_counter=0;  
    g_flash_rd_counter=0;
}

void set_data_to_flash(uint8_t* data,int len)
{   
    if(g_flash_wr_counter<FLASH_RECORD_SIZE)
    {
        esp_partition_write(data_partition, g_flash_wr_counter, data, len);
        g_flash_wr_counter+=len;
    }    
}


int get_data_from_flash(uint8_t* data)
{
    if(g_flash_rd_counter<g_flash_wr_counter)
    {
        esp_partition_read(data_partition, g_flash_rd_counter, data, FLASH_SECTOR_SIZE);
        g_flash_rd_counter+=FLASH_SECTOR_SIZE;

        if(g_flash_rd_counter<g_flash_wr_counter)
        {
            return FLASH_SECTOR_SIZE;
        }
        else
        {
            int len=g_flash_wr_counter+FLASH_SECTOR_SIZE-g_flash_rd_counter;
            g_flash_wr_counter=0;  
            g_flash_rd_counter=0;
            return len;
        }
    }
    else
    {
        return 0;
    }
    
}
void i2s_play_flash()
{
    int play_len=get_data_from_flash(flash_read_buff);
    size_t bytes_written;
    if(play_len>0)
    {
        i2s_set_dac_mode(I2S_DAC_CHANNEL_BOTH_EN);
        vTaskDelay(500 / portTICK_PERIOD_MS);
        while(play_len>0)
        {
            
            int i2s_wr_len = example_i2s_dac_data_scale(i2s_write_buff,flash_read_buff , play_len);
            i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, i2s_wr_len, &bytes_written, portMAX_DELAY);

            play_len=get_data_from_flash(flash_read_buff);
        }

        memset(i2s_write_buff,127,EXAMPLE_I2S_READ_LEN);
        i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, EXAMPLE_I2S_READ_LEN, &bytes_written, portMAX_DELAY);
        vTaskDelay(500 / portTICK_PERIOD_MS);
        i2s_set_dac_mode(I2S_DAC_CHANNEL_DISABLE);
        ESP_ERROR_CHECK(esp_partition_erase_range(data_partition, 0, FLASH_ERASE_SIZE));
    }
    
}

void i2s_tcp_conn_audio()
{
    size_t bytes_read, bytes_written;

    // 4. Play an example audio file(file format: 8bit/16khz/single channel)
    printf("Playing i2s_tcp_conn_audio \n");
    int offset = 0;
    int tot_size = sizeof(audio_tcp_conn);

    i2s_set_dac_mode(I2S_DAC_CHANNEL_BOTH_EN);
    vTaskDelay(500 / portTICK_PERIOD_MS);
    while (offset < tot_size) {
        int play_len = ((tot_size - offset) > (4 * 1024)) ? (4 * 1024) : (tot_size - offset);
        int i2s_wr_len = example_i2s_dac_data_scale(i2s_write_buff, (uint8_t*)(audio_tcp_conn + offset), play_len);
        i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, i2s_wr_len, &bytes_written, portMAX_DELAY);
        offset += play_len;
    }
    memset(i2s_write_buff,127,EXAMPLE_I2S_READ_LEN);
    i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, EXAMPLE_I2S_READ_LEN, &bytes_written, portMAX_DELAY);
    vTaskDelay(500 / portTICK_PERIOD_MS);
    i2s_set_dac_mode(I2S_DAC_CHANNEL_DISABLE);       
 
}
void i2s_wake_up_audio()
{
    size_t bytes_read, bytes_written;

    // 4. Play an example audio file(file format: 8bit/16khz/single channel)
    printf("Playing i2s_wake_up_audio \n");
    int offset = 0;
    int tot_size = sizeof(audio_wake_up);

    i2s_set_dac_mode(I2S_DAC_CHANNEL_BOTH_EN);
    vTaskDelay(500 / portTICK_PERIOD_MS);
    while (offset < tot_size) {
        int play_len = ((tot_size - offset) > (4 * 1024)) ? (4 * 1024) : (tot_size - offset);
        int i2s_wr_len = example_i2s_dac_data_scale(i2s_write_buff, (uint8_t*)(audio_wake_up + offset), play_len);
        i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, i2s_wr_len, &bytes_written, portMAX_DELAY);
        offset += play_len;
    }
    memset(i2s_write_buff,127,EXAMPLE_I2S_READ_LEN);
    i2s_write(EXAMPLE_I2S_NUM, i2s_write_buff, EXAMPLE_I2S_READ_LEN, &bytes_written, portMAX_DELAY);
    vTaskDelay(500 / portTICK_PERIOD_MS);
    i2s_set_dac_mode(I2S_DAC_CHANNEL_DISABLE);       
 
}